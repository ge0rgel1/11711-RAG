For training data, Alan Wang build the first 20 questions/answers. Shi Zhuo Li built 20 - 40 questions/answers. Chuangji Li built the rest questions/answers.

For testing questions, Alan Wang built the first 35 questions/answers. Shi Zhuo Li built 35 - 70 questions/answers. Chuangji built 75 - 105 questions/answers.

For database:
    Alan Wang:
        Faculty and LTI 
        Events

    Shizhuo Li:
        Courses CMU
        History

    Chuangji Li:
        Academics CMU

Code writing:
    Alan Wang:
        data preprocessing, writing script of LTI faculty and research paper retrieval. writing the script of CMU commencement and spring carnival info retreival

    Shizhuo Li:
        data processing, writing script of CMU course schedule, calendar, CMU history, SCS history, athletics retrieval, and refining script of LTI faculty and research paper retrieval.
        Question-Answer pair generation
        Evaluation metrics
    
    Chuangji Li:
        data processing, writing script of Academics. 
        RAG System
        model testing
        testing llm as retriever
        significance test
        
        

Report writing:
    Alan Wang:
        Introduction
        Data Annotation

    Shizhuo Li:
        Abstract
        Data
        Reference
        Knowledge Source
    
    Chuangji Li:
        Architecture
        Experiment
        Analysis
        Result
        Conclusion