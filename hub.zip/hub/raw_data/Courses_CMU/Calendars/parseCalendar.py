
import re

# patternDate = re.compile(r'^(January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{1,2}+[A-Za-z]{1,3}(.*?)\s')
with open('Calendar_Line.txt', 'r', encoding='utf-8') as file , open('Calendar_scentences.txt', 'w', encoding='utf-8') as scentOut:
    Sem = None
    for line in file:
        textLine = line.split()
        out = line
        if textLine[0] == "Date:":
            Date = textLine[1] + " " + textLine[2][:-1] + ", " + textLine[3][:-1]
            Event = "".join(textLine[5:])
            out = "The date of " + Event + " is " + Date + " in " + Sem + '\n'
        if textLine[0] == "Fall":
            Sem = "Fall 2023"
        if textLine[0] == "Spring":
            Sem = "Spring 2024"
        if textLine[0] == "Summer":
            Sem = "Summer 2024"
        scentOut.write(out)