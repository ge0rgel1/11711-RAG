import torch
import re

SYSTEMPROMPT = "You are given a question relevant to CMU. Answer the question with factual statement"
Total = []
with open('scheduleofclasses_Lines.txt', 'r', encoding='utf-8') as FL, open('scheduleofclasses_Scentences.txt', 'r', encoding='utf-8') as FS:
    lines = FL.readlines()
    scentences = FS.readlines()
    for line, scentence in zip(lines, scentences):
        contextLine = scentence.strip()
        linePattern = r"Department:(.*?); Class Number: (.*?); Class Title: (.*?); Unit: (.*?); Days: (.*?); Begin: (.*?); End: (.*?); Room: (.*?); Location: (.*?); Instructor\(s\): (.*?)\."
        match = re.match(linePattern, line)
        C = {
            'Department': match.group(1).strip(),
            'Class Number': match.group(2).strip(),
            'Class Title': match.group(3).strip(),
            'Unit': match.group(4).strip(),
            'Days': match.group(5).strip(),
            'Begin': match.group(6).strip(),
            'End': match.group(7).strip(),
            'Room': match.group(8).strip(),
            'Location': match.group(9).strip(),
            'Instructor(s)':match.group(10).strip(),           
        }
        Questions = [
            "What is the Course Number of " + C['Class Title'],
            "What is the Course Title of " + C['Class Number'],
            "What is the department of the course " + C['Class Title'],
            "What is the department of the course " + C['Class Number'],
            "How many units is the course " + C['Class Title'],
            "How many units is the course " + C['Class Number'],
            "When is the class scheduled of " + C['Class Title'],
            "When is the class scheduled of " + C['Class Number'],
            "When is the class of " + C['Class Title'] + " being held",
            "When is the class of " + C['Class Number'] + " being held",
            "What is the room "+ C['Class Title'] + " being held",
            "What is the room "+ C['Class Number'] + " being held",
            "Where is the location of" + C['Class Title'] + " being held",
            "Where is the location of" + C['Class Number'] + " being held",
            "Where is " + C['Class Title'] + " being held",
            "Where is " + C['Class Number'] + " being held",
            "Who is the instructor of " + C['Class Title'] + " being held",
            "Who is the instructor of " + C['Class Number'] + " being held",
            "Who is teaching "+ C['Class Title'],
            "Who is teaching "+ C['Class Number'],
            "What is the course " + C['Class Title'],
            "What is the course " + C['Class Number'],
        ]
        Answers = [
            C['Class Number'],
            C['Class Title'],
            C['Department'],
            C['Department'],
            C['Unit'],
            C['Unit'],
            C['Days'] + " From " + C['Begin'] + " to " + C['End'],
            C['Days'] + " From " + C['Begin'] + " to " + C['End'],
            C['Days'] + " From " + C['Begin'] + " to " + C['End'],
            C['Days'] + " From " + C['Begin'] + " to " + C['End'],
            C['Room'],
            C['Room'],
            C['Room'] + " on " + C['Location'] + " campus",
            C['Room'] + " on " + C['Location'] + " campus",
            C['Room'] + " on " + C['Location'] + " campus",
            C['Room'] + " on " + C['Location'] + " campus",
            C['Instructor(s)'],  
            C['Instructor(s)'],  
            C['Instructor(s)'],  
            C['Instructor(s)'],  
            contextLine,
            contextLine
        ]
        for i in range(len(Questions)):
            outStr = SYSTEMPROMPT + "; " + contextLine + "; " + Questions[i] + "; " + Answers[i] + '\n'
            Total.append(outStr)

with open('ScheduleQA.txt', 'w', encoding='utf-8') as file:
    for cont in Total:
        file.write(cont)


