import re

def getTag(s):
    deptNum = ["48", "60", "93", "52", "03", "42", "70", "62", "39", "97", "99", "06", "09", "12", "02", "15", "62", "51", "66", "54", "73", "18", "19", "62",
               "76", "53", "65", "94", "79", "05", "62", "04", "14", "67", "95", "84", "49", "11", "38", "10", "27", "21", "24", "92", "82", "57", "32", "86", "80", "69", "33", "85"
               "91", "90", "16", "07", "62", "88", "17", "36", "98"]
    tags = ['Architecture', 'Art', 'Arts & Entertainment Management', 'BXA Intercollege Degree Programs', 'Biological Sciences', 'Biomedical Engineering', 'Business Administration', 'CFA Interdisciplinary', 'CIT Interdisciplinary', 'CMUQ-Wide Studies',
            'Carnegie Mellon University-Wide Studies', 'Chemical Engineering', 'Chemistry', 'Civil & Environmental Engineering', 'Computational Biology', 'Computer Science', 'Computer Science and Arts','Design', 'Dietrich College Interdisciplinary', 'Drama', 
            'Economics', 'Electrical & Computer Engineering ', 'Engineering & Public Policy', 'Engineering Studies and Arts', 'English ', 'Entertainment Technology', 'General Dietrich College', 'Heinz College Wide Courses', 'History', 'Human-Computer Interaction', 'Humanities and Arts', 
            'Information & Communication Technology', 'Information Networking Institute', 'Information Systems Program', 'Information Systems:Sch of IS & Mgt', 'Institute for Politics and Strategy', 'Integrated Innovation Institute', 
            'Language Technologies Institute', 'MCS Interdisciplinary', 'Machine Learning', 'Materials Science & Engineering', 'Mathematical Sciences', 'Mechanical Engineering', 'Medical Management:Sch of Pub Pol & Mgt', 'Modern Languages', 
            'Music', 'Naval Science - ROTC', 'Neuroscience Institute', 'Philosophy', 'Physical Education', 'Physics', 'Psychology', 'Public Management:Sch of Pub Pol & Mgt', 'Public Policy & Mgt:Sch of Pub Pol & Mgt', 'Robotics', 'SCS Interdisciplinary', 
            'Science and Arts','Social & Decision Sciences', 'Software & Societal Systems', 'Statistics and Data Science', 'StuCo (Student Led Courses)']
    for i in range(len(deptNum)):
        if deptNum[i] == s[:2]:
            return tags[i]

with open('Scheduleofclasses_Original.txt', 'r', encoding='utf-8') as file:
    textTotal = file.read()

pattern1 = re.compile(
    r'(\d{5})\s+(.*?)\s+(\d{1,2}\.?\d?|\d+-\d+|\d,\d|\d,\d,\d|VAR)\s+([A-Z]{1,3}|[0-9]{1,3}|Lec \d+|[A-Za-z]{1,3}\d)\s+([MTWRF]+|TBA)\s+([0-9:APM]+|TBA)?\s+([0-9:APM]+|TBA)?\s+([A-Z\d\s]+|DNM|TBA)\s+(Pittsburgh, Pennsylvania|Kigali, Rwanda|San Jose, California|Lisbon, Portugal|Doha, Qatar)\s+([\w, ]+)'
)
pattern2 = re.compile(
    r'(\d{5})\s+(.*?)\s+(\d{1,2}\.?\d?|\d+-\d+|VAR|\d,\d|\d,\d,\d)\s+(.*?)\s+([A-Za-z]{1,3}|[0-9]{1,3}|Lec \d+|[A-Za-z]{1,3}\d)\s+([MTWRF]+|TBA)\s+([0-9:APM]+|TBA)?\s+([0-9:APM]+|TBA)?\s+([A-Z\d\s]+|DNM|TBA)\s+(Pittsburgh, Pennsylvania|Kigali, Rwanda|San Jose, California|Lisbon, Portugal|Doha, Qatar)\s+([\w, ]+)'
)
courses = []
for match in re.finditer(pattern1, textTotal):
    ww = match.group(2)
    if match.group(2)[-1] == ':':
        ww = match.group(2)[:-1]
    courses.append((1, match.start(), {
        'Class Number': match.group(1),
        'Class Title': ww,
        'Unit': match.group(3),
        'Days': match.group(5),
        'Begin': match.group(6),
        'End': match.group(7),
        'Room': match.group(8),
        'Location': match.group(9),
        'Instructor(s)': match.group(10)
    }))

for match in re.finditer(pattern2, textTotal):
    ww = match.group(2)
    if match.group(2)[-1] == ':':
        ww = match.group(2)[:-1]
    courses.append((2, match.start(), {
        'Class Number': match.group(1),
        'Class Title': ww,
        'Unit': match.group(3),
        'Days': match.group(6),
        'Begin': match.group(7),
        'End': match.group(8),
        'Room': match.group(9),
        'Location': match.group(10),
        'Instructor(s)': match.group(11)
    }))

courses.sort(key=lambda x: x[1])


AllC = []
seenSet = set()
# Print out the formatted courses
for x, _, course in courses:
    if course['Class Number'] not in seenSet:
        seenSet.add(course['Class Number'])
        AllC.append(course)

cont = ""
for course in AllC: 
    tag = getTag(course['Class Number'])
    if tag is None:
        tag = "NA"
    cont += "Department:" + tag + "; " + f"Class Number: {course['Class Number']}; Class Title: {course['Class Title']}; Unit: {course['Unit']}; Days: {course['Days']}; Begin: {course['Begin']}; End: {course['End']}; Room: {course['Room']}; Location: {course['Location']}; Instructor(s): {course['Instructor(s)']}." + "\n"

with open('Scheduleofclasses_Lines.txt', 'w',  encoding='utf-8') as newFile:
    newFile.write(cont)       
    # print(f"Class Number: {course['Class Number']}; Class Title: {course['Class Title']}; Unit: {course['Unit']}; Days: {course['Days']}; Begin: {course['Begin']}; End: {course['End']}; Room: {course['Room']}; Location: {course['Location']}; Instructor(s): {course['Instructor(s)']}.")

cont = ""
for course in AllC: 
    tag = getTag(course['Class Number'])
    if tag is None:
        tag = "NA"
    cont += f"{course['Class Title']}, (class number {course['Class Number']}), is a {course['Unit']}-unit course offered by CMU " + tag + " Department, " + f"which is taught by {course['Instructor(s)']} on {course['Days']} from {course['Begin']} to {course['End']} in {course['Room']} on {course['Location']} campus" + "\n"

with open('Scheduleofclasses_Scentences.txt', 'w',  encoding='utf-8') as nF:
    nF.write(cont)
