import re

ALL = []
SYSTEMPROMPT = "You are given a question relevant to CMU. Answer the question with factual statement"
with open('Calendar_Line.txt', 'r', encoding='utf-8') as LF, open('Calendar_scentences.txt', 'r', encoding='utf-8') as SF:
    for line, sent in zip(LF, SF):
        contextLine = sent.strip()
        LinePattern = r"Date: (.*?); (.*?); Event: (.*)"
        match = re.match(LinePattern, line)
        if match is None:
            continue
        year = contextLine.split()[-2:]
        C = {
            'Date': match.group(1).strip() + ", " + match.group(2).strip(),
            'Event': match.group(3).strip()     
        }
        Q1 = [
            "When is " + C['Event'],
            "What is the time of " + C['Event'],
        ]
        A1 = [
            C['Date'],
            C['Date']
        ]
        for i in range(len(Q1)):
            outStr = SYSTEMPROMPT + "; " + contextLine + "; " + Q1[i] + "; " + A1[i] + " in " + " ".join(year)+ '\n'
            ALL.append(outStr)
            
    for month, day in zip(['January', 'Febuary', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'], [str(i+1) for i in range(31)]):
        Date = month + ' ' + day
        Q2 = [
            "What are the events on " + Date,
            "Are there any events on " + Date
        ]
        for line, sent in LF:
            contextLine = sent.strip()
            LinePattern = r"Date: (.*?); (.*?); Event: (.*?)"
            match = re.match(LinePattern, line)
            if match is None:
                continue
            year = contextLine.split()[-2:]
            currDate = match.group(1).strip()
            if currDate == Date:
                out = match.group(3)
                outStr = SYSTEMPROMPT + "; " + contextLine + "; " + Q2[i] + "; " + out.strip() + " in " + " ".join(year) + '\n'
                ALL.append(outStr).append(outStr)
                break
            
with open('CalendarOA.txt', 'w', encoding='utf-8') as file:
    for i in range(len(ALL)):
        file.write(ALL[i])