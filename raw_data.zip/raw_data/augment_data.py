# Template = f"""Context: Below is information 
# about Carnegie Mellon University course schedule. The course of interest is {Class_Title}.
# The course number is {Class_Number} or {Class_Number[0:2] + "-" + Class_Number[2:]}. 
# The course {Class_Title}({Class_Number}) has {Unit} unit.
# The professor/instructor of {Class_Title}({Class_Number}) in Spring 2024 is {Instructor}. 
# The department of {Class_Title}({Class_Number}) is {Department}.
# The location of {Class_Title}({Class_Number}) is {Location}.
# The room of {Class_Title}({Class_Number}) is {Room}.
# The course happens in {Days}.
# """

# Template = f"""Context: Below is information 
#         about Carnegie Mellon University course schedule. The course of interest is {C['Class Title']}.
#         The course number is {C['Class Number']} or {C['Class Number'][0:2] + "-" + C['Class Number'][2:]}. 
#         The course {C['Class Title']}({C['Class Number']}) has {C['Unit']} unit.
#         The professor/instructor of {C['Class Title']}({C['Class Number']}) in Spring 2024 is {C['Instructor(s)']}. 
#         The department of {C['Class Title']}({C['Class Number']}) is {C['Department']}.
#         The location of {C['Class Title']}({C['Class Number']}) is {C['Location']}.
#         The room of {C['Class Title']}({C['Class Number']}) is {C['Room']}.
#         The course happens in {C['Days']}.
#         """

import torch
import re

# Template = f"""Context: Below is information about Carnegie Mellon University course schedule. The course of interest is {Class_Title}. The course number is {Class_Number} or {Class_Number[0:2] + "-" + Class_Number[2:]}. The course {Class_Title}({Class_Number}) has {Unit} unit. The professor/instructor of {Class_Title}({Class_Number}) in Spring 2024 is {Instructor}. The department of {Class_Title}({Class_Number}) is {Department}. The location of {Class_Title}({Class_Number}) is {Location}. The room of {Class_Title}({Class_Number}) is {Room}. The course happens in {Days}.""" + "\n"

path_lines = "Scheduleofclasses_Lines.txt"
path_sentences = "Scheduleofclasses_Scentences.txt"
path_out = "augment.txt"
total_lines = []

with open(path_lines, 'r', encoding='utf-8') as FL: #, open(path_sentences, 'r', encoding='utf-8') as FS:
    lines = FL.readlines()
    for line in lines:
        linePattern = r"Department:(.*?); Class Number: (.*?); Class Title: (.*?); Unit: (.*?); Days: (.*?); Begin: (.*?); End: (.*?); Room: (.*?); Location: (.*?); Instructor\(s\): (.*?)\."
        match = re.match(linePattern, line)
        C = {
            'Department': match.group(1).strip(),
            'Class Number': match.group(2).strip(),
            'Class Title': match.group(3).strip(),
            'Unit': match.group(4).strip(),
            'Days': match.group(5).strip(),
            'Begin': match.group(6).strip(),
            'End': match.group(7).strip(),
            'Room': match.group(8).strip(),
            'Location': match.group(9).strip(),
            'Instructor(s)':match.group(10).strip(),           
        }
        if C['Days'] == "TBA":
            C['Days'] = "days not yet decided"
        if C['Instructor(s)'] == "TBA":
            C['Instructor(s)'] = "not yet decided"
        if C['Room'] == "TBA":
            C['Room'] = "not yet decided"
        if C['Location'] == "TBA":
            C['Location'] = "not yet decided"
        if C['Instructor(s)'] == "TBA":
            C['Instructor(s)'] = "not yet decided"
        Template = f"""Below is information about CMU course {C['Class Title']}. The course number is {C['Class Number']} or {C['Class Number'][0:2] + "-" + C['Class Number'][2:]}. The course {C['Class Title']}({C['Class Number']}) has {C['Unit']} unit. The professor {C['Instructor(s)']} is teaching the course {C['Class Title']}({C['Class Number']}). The professor/instructor of {C['Class Title']}({C['Class Number']}) in Spring 2024 is {C['Instructor(s)']}. The department of {C['Class Title']}({C['Class Number']}) is {C['Department']}. The location of {C['Class Title']}({C['Class Number']}) is {C['Location']}. The room of {C['Class Title']}({C['Class Number']}) is {C['Room']}. The course happens in {C['Days']}.\n"""
        total_lines.append(Template)
        

with open(path_out, 'w', encoding='utf-8') as file:
    for line in total_lines:
        file.write(line)